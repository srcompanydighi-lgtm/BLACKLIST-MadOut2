BLACKLIST PUBLIC APP (PWA-READY WEBSITE)
=======================================

This package is prepared to be hosted publicly and installed on Android as a web app.

PUBLISH WITH GITHUB PAGES
1. Sign in to GitHub and create a new public repository.
2. Upload ALL files from this folder (index.html, manifest.webmanifest, icon.svg, service-worker.js, README.txt) to the repository root.
3. Open repository Settings -> Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
5. Wait for GitHub Pages to publish and copy the HTTPS URL it gives you.

INSTALL ON ANDROID
1. Open the published HTTPS URL in Chrome.
2. Tap the three-dot menu.
3. Choose "Install app" or "Add to Home screen" if offered.

IMPORTANT
- This ZIP does not create a live public URL by itself; it must be uploaded to a hosting provider.
- The application form currently stores submissions only in the visitor's own browser. Admins cannot see applications submitted on other devices. A secure backend/database and server-side admin login are required for real shared applications.
- The demo PIN in index.html is visible to anyone inspecting the source. Do not treat it as secure.
